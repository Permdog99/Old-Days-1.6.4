package net.minecraft.src.nbxlite.spawners;

public class SpawnListEntryBeta
{
    public SpawnListEntryBeta(Class class1, int i)
    {
        entityClass = class1;
        spawnRarityRate = i;
    }

    public Class entityClass;
    public int spawnRarityRate;
}

