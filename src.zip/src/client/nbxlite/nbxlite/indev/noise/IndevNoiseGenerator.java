package net.minecraft.src.nbxlite.indev.noise;

public abstract class IndevNoiseGenerator
{
    public IndevNoiseGenerator()
    {
    }

    public abstract double a(double d, double d1);
}
