package net.minecraft.src.nbxlite.format;

class Empty2
{
}
