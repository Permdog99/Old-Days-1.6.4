package net.minecraft.src.ssp;

public class SSPOptions{
    public static boolean getDebugSeed(){
        return true;
    }

    public static boolean getShareButton(){
        return true;
    }

    public static boolean getSMPButton(){
        return true;
    }

    public static boolean getDeathMessages(){
        return false;
    }
}